package com.vw.pizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaOrderingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
