package com.vw.pizza.dao;

public interface PizzaDao {

}
