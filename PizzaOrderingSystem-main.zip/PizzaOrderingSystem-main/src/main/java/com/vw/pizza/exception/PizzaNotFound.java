package com.vw.pizza.exception;

public class PizzaNotFound {

}
