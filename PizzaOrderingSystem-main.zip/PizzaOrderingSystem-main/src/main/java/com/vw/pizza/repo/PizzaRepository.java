package com.vw.pizza.repo;

public interface PizzaRepository {

}
